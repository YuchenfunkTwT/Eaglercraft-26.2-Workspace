package net.minecraft.client;

/** VoidMeteorShower cilent: simple on/off state for the built-in mods. */
public final class ModManager {
   public static boolean zoom = true;
   public static boolean showFps = false;
   public static boolean showCoords = false;
   public static boolean fullbright = false;
   public static boolean autoSprint = false;

   private ModManager() {
   }
}
