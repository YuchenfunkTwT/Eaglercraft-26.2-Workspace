package net.minecraft.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** VoidMeteorShower cilent: small HUD overlay for the FPS and coordinates mods. */
public final class ModHud {
   private ModHud() {
   }

   private static String fmt(final double value) {
      return Double.toString(Math.round(value * 10.0) / 10.0);
   }

   public static void extract(final Minecraft minecraft, final GuiGraphicsExtractor graphics) {
      if (minecraft.player == null || minecraft.gui.screen() != null) {
         return;
      }

      int y = 4;
      if (ModManager.showFps) {
         graphics.text(minecraft.font, "FPS: " + minecraft.getFps(), 4, y, -1);
         y += 10;
      }

      if (ModManager.showCoords) {
         graphics.text(minecraft.font,
            "XYZ: " + fmt(minecraft.player.getX()) + " / " + fmt(minecraft.player.getY()) + " / " + fmt(minecraft.player.getZ()),
            4, y, -1);
      }
   }
}
