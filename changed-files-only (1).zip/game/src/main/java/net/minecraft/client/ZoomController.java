package net.minecraft.client;

import net.minecraft.util.Mth;

/**
 * VoidMeteorShower cilent smooth zoom.
 * Hold the zoom key (default C) to smoothly zoom in, scroll the mouse wheel
 * while holding to change the zoom level, release to smoothly zoom back out.
 */
public final class ZoomController {
   private static final float MIN_FACTOR = 0.05F;
   private static final float MAX_FACTOR = 0.90F;
   private static final float DEFAULT_FACTOR = 0.25F;
   private static final float SMOOTH_SPEED = 14.0F;

   private static float targetFactor = DEFAULT_FACTOR;
   private static float currentFactor = 1.0F;
   private static long lastNanos = 0L;

   private ZoomController() {
   }

   private static boolean isHeld(final Minecraft minecraft) {
      return ModManager.zoom && minecraft.gui.screen() == null && minecraft.options.keyZoom.isDown();
   }

   /** Called once per rendered frame. */
   public static void update(final Minecraft minecraft) {
      long now = System.nanoTime();
      float dt = lastNanos == 0L ? 0.016F : Math.min((now - lastNanos) / 1.0E9F, 0.1F);
      lastNanos = now;
      float goal = isHeld(minecraft) ? targetFactor : 1.0F;
      float t = 1.0F - (float)Math.exp(-SMOOTH_SPEED * dt);
      currentFactor += (goal - currentFactor) * t;
      if (Math.abs(goal - currentFactor) < 0.0005F) {
         currentFactor = goal;
      }
   }

   /** Multiplier applied to the field of view (1.0 = no zoom). */
   public static float fovFactor() {
      return currentFactor;
   }

   public static boolean isZooming() {
      return currentFactor < 0.999F;
   }

   /** Mouse sensitivity multiplier so aiming stays controllable while zoomed. */
   public static double sensitivityFactor() {
      return Mth.clamp(currentFactor, 0.15F, 1.0F);
   }

   /** Returns true when the scroll was used for zooming (and must not change the hotbar). */
   public static boolean onScroll(final Minecraft minecraft, final double yOffset) {
      if (!isHeld(minecraft) || yOffset == 0.0) {
         return false;
      }

      targetFactor = Mth.clamp(targetFactor * (float)Math.pow(0.88, yOffset), MIN_FACTOR, MAX_FACTOR);
      return true;
   }

   public static void resetLevel() {
      targetFactor = DEFAULT_FACTOR;
   }
}
