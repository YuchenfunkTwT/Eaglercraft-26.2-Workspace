package net.minecraft.client.gui.screens;

import net.minecraft.client.ModManager;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/** VoidMeteorShower cilent mod panel: toggle the built-in mods on and off. */
public class ModMenuScreen extends Screen {
   private final Screen lastScreen;

   public ModMenuScreen(final Screen lastScreen) {
      super(Component.literal("VoidMeteorShower cilent - Mods"));
      this.lastScreen = lastScreen;
   }

   private static Component label(final String name, final boolean on) {
      return Component.literal(name + ": " + (on ? "ON" : "OFF"));
   }

   @Override
   protected void init() {
      int x = this.width / 2 - 100;
      int y = this.height / 4;
      Button zoom = Button.builder(label("Smooth Zoom (hold C)", ModManager.zoom), b -> {
         ModManager.zoom = !ModManager.zoom;
         b.setMessage(label("Smooth Zoom (hold C)", ModManager.zoom));
      }).bounds(x, y, 200, 20).build();
      Button fps = Button.builder(label("FPS Display", ModManager.showFps), b -> {
         ModManager.showFps = !ModManager.showFps;
         b.setMessage(label("FPS Display", ModManager.showFps));
      }).bounds(x, y + 24, 200, 20).build();
      Button coords = Button.builder(label("Coordinates", ModManager.showCoords), b -> {
         ModManager.showCoords = !ModManager.showCoords;
         b.setMessage(label("Coordinates", ModManager.showCoords));
      }).bounds(x, y + 48, 200, 20).build();
      Button bright = Button.builder(label("Fullbright", ModManager.fullbright), b -> {
         ModManager.fullbright = !ModManager.fullbright;
         b.setMessage(label("Fullbright", ModManager.fullbright));
      }).bounds(x, y + 72, 200, 20).build();
      Button sprint = Button.builder(label("Auto Sprint", ModManager.autoSprint), b -> {
         ModManager.autoSprint = !ModManager.autoSprint;
         b.setMessage(label("Auto Sprint", ModManager.autoSprint));
      }).bounds(x, y + 96, 200, 20).build();
      this.addRenderableWidget(zoom);
      this.addRenderableWidget(fps);
      this.addRenderableWidget(coords);
      this.addRenderableWidget(bright);
      this.addRenderableWidget(sprint);
      this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose()).bounds(x, y + 132, 200, 20).build());
   }

   @Override
   public void extractRenderState(final GuiGraphicsExtractor graphics, final int mouseX, final int mouseY, final float a) {
      super.extractRenderState(graphics, mouseX, mouseY, a);
      graphics.centeredText(this.font, this.title, this.width / 2, this.height / 4 - 20, -1);
   }

   @Override
   public void onClose() {
      this.minecraft.gui.setScreen(this.lastScreen);
      if (this.lastScreen == null) {
         this.minecraft.mouseHandler.grabMouse();
      }
   }
}
